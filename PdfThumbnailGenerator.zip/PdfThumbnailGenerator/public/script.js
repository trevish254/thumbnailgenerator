// Award-winning PDF Thumbnail Generator - Frontend JavaScript
class ThumbnailGenerator {
    constructor() {
        this.apiUrl = window.location.origin;
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadRecentThumbnails();
        this.startStatusCheck();
    }

    bindEvents() {
        // Form submission
        document.getElementById('thumbnailForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.generateThumbnail();
        });

        // Retry button
        document.getElementById('retryBtn').addEventListener('click', () => {
            this.hideAllSections();
            this.showSection('generator-section');
        });

        // Copy URL button
        document.getElementById('copyUrlBtn').addEventListener('click', () => {
            this.copyToClipboard();
        });

        // Download button
        document.getElementById('downloadBtn').addEventListener('click', () => {
            this.downloadThumbnail();
        });

        // Refresh recent thumbnails
        document.getElementById('refreshBtn').addEventListener('click', () => {
            this.loadRecentThumbnails();
        });

        // Real-time URL validation
        document.getElementById('pdfUrl').addEventListener('input', (e) => {
            this.validateUrl(e.target);
        });

        // Real-time document ID validation
        document.getElementById('documentId').addEventListener('input', (e) => {
            this.validateDocumentId(e.target);
        });
    }

    validateUrl(input) {
        const url = input.value.trim();
        const isValid = this.isValidUrl(url);
        
        if (url && !isValid) {
            input.setCustomValidity('Please enter a valid URL');
        } else {
            input.setCustomValidity('');
        }
    }

    validateDocumentId(input) {
        const documentId = input.value.trim();
        
        if (documentId && !documentId.match(/^[a-zA-Z0-9_-]+$/)) {
            input.setCustomValidity('Document ID can only contain letters, numbers, hyphens, and underscores');
        } else {
            input.setCustomValidity('');
        }
    }

    isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }

    async generateThumbnail() {
        const pdfUrl = document.getElementById('pdfUrl').value.trim();
        const documentId = document.getElementById('documentId').value.trim();
        
        if (!pdfUrl) {
            this.showError('Please enter a PDF URL');
            return;
        }

        if (!documentId) {
            this.showError('Please enter a document ID');
            return;
        }

        if (!this.isValidUrl(pdfUrl)) {
            this.showError('Please enter a valid URL');
            return;
        }

        if (!documentId.match(/^[a-zA-Z0-9_-]+$/)) {
            this.showError('Document ID can only contain letters, numbers, hyphens, and underscores');
            return;
        }

        this.showLoading();
        
        try {
            const response = await fetch(`${this.apiUrl}/generate-thumbnail`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    fileUrl: pdfUrl,
                    documentId: documentId
                })
            });

            const data = await response.json();

            if (data.success) {
                this.showSuccess(data);
                this.loadRecentThumbnails(); // Refresh recent thumbnails
            } else {
                this.showError(data.message || data.error || 'Failed to generate thumbnail');
            }
        } catch (error) {
            console.error('Error:', error);
            this.showError('Network error. Please check your connection and try again.');
        }
    }

    showLoading() {
        this.hideAllSections();
        this.showSection('loadingSection');
        
        // Update loading text with animated dots
        const loadingText = document.getElementById('loadingText');
        let dots = '';
        const interval = setInterval(() => {
            dots = dots.length >= 3 ? '' : dots + '.';
            loadingText.textContent = `Processing PDF and uploading to Supabase${dots}`;
        }, 500);
        
        // Store interval ID to clear it later
        this.loadingInterval = interval;
    }

    showSuccess(data) {
        this.hideAllSections();
        this.clearLoadingInterval();
        
        // Update result section
        const thumbnailImage = document.getElementById('thumbnailImage');
        const processingTime = document.getElementById('processingTime');
        
        thumbnailImage.src = `${this.apiUrl}${data.thumbnailUrl}`;
        thumbnailImage.alt = 'Generated Thumbnail';
        processingTime.textContent = `Processing time: ${data.processingTime}`;
        
        // Store current thumbnail URL for actions
        this.currentThumbnailUrl = `${this.apiUrl}${data.thumbnailUrl}`;
        
        this.showSection('resultSection');
        
        // Add success animation
        const resultCard = document.querySelector('#resultSection .card');
        resultCard.classList.add('success-animation');
        
        // Show success notification
        this.showNotification('Thumbnail generated successfully!', 'success');
    }

    showError(message) {
        this.hideAllSections();
        this.clearLoadingInterval();
        
        document.getElementById('errorMessage').textContent = message;
        this.showSection('errorSection');
        
        // Show error notification
        this.showNotification(message, 'error');
    }

    showSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            section.style.display = 'block';
            section.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    hideAllSections() {
        const sections = ['loadingSection', 'resultSection', 'errorSection'];
        sections.forEach(sectionId => {
            const section = document.getElementById(sectionId);
            if (section) {
                section.style.display = 'none';
            }
        });
    }

    clearLoadingInterval() {
        if (this.loadingInterval) {
            clearInterval(this.loadingInterval);
            this.loadingInterval = null;
        }
    }

    async copyToClipboard() {
        if (!this.currentThumbnailUrl) return;

        try {
            await navigator.clipboard.writeText(this.currentThumbnailUrl);
            this.showNotification('URL copied to clipboard!', 'success');
            
            // Visual feedback
            const copyBtn = document.getElementById('copyUrlBtn');
            const originalText = copyBtn.innerHTML;
            copyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
            
            setTimeout(() => {
                copyBtn.innerHTML = originalText;
            }, 2000);
        } catch (err) {
            console.error('Failed to copy URL:', err);
            this.showNotification('Failed to copy URL', 'error');
        }
    }

    downloadThumbnail() {
        if (!this.currentThumbnailUrl) return;

        const link = document.createElement('a');
        link.href = this.currentThumbnailUrl;
        link.download = `thumbnail-${Date.now()}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        this.showNotification('Download started!', 'success');
    }

    async loadRecentThumbnails() {
        try {
            const response = await fetch(`${this.apiUrl}/thumbnails-list`);
            const data = await response.json();

            if (data.success) {
                this.displayRecentThumbnails(data.thumbnails);
            } else {
                console.error('Failed to load recent thumbnails:', data.error);
            }
        } catch (error) {
            console.error('Error loading recent thumbnails:', error);
        }
    }

    displayRecentThumbnails(thumbnails) {
        const container = document.getElementById('recentThumbnails');
        
        if (thumbnails.length === 0) {
            container.innerHTML = `
                <div style="text-align: center; padding: 2rem; color: var(--text-muted);">
                    <i class="fas fa-image" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                    <p>No thumbnails generated yet</p>
                    <p>Generate your first thumbnail above!</p>
                </div>
            `;
            return;
        }

        // Show only the 6 most recent thumbnails
        const recentThumbnails = thumbnails.slice(0, 6);
        
        container.innerHTML = recentThumbnails.map(thumbnail => `
            <div class="thumbnail-item" onclick="window.open('${this.apiUrl}${thumbnail.url}', '_blank')">
                <img src="${this.apiUrl}${thumbnail.url}" alt="Thumbnail" loading="lazy">
                <div class="thumbnail-item-info">
                    <h4>${thumbnail.filename}</h4>
                    <p>${this.formatFileSize(thumbnail.size)} • ${this.formatDate(thumbnail.created)}</p>
                </div>
            </div>
        `).join('');
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;

        // Add notification styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            color: white;
            font-weight: 500;
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
            background: ${type === 'success' ? 'var(--success-color)' : type === 'error' ? 'var(--error-color)' : 'var(--primary-color)'};
            box-shadow: var(--shadow-lg);
            max-width: 400px;
        `;

        document.body.appendChild(notification);

        // Remove notification after 4 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-out forwards';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 4000);
    }

    async startStatusCheck() {
        try {
            const response = await fetch(`${this.apiUrl}/health`);
            const data = await response.json();
            
            if (data.status === 'healthy') {
                this.updateServerStatus('online');
            } else {
                this.updateServerStatus('offline');
            }
        } catch (error) {
            this.updateServerStatus('offline');
        }
    }

    updateServerStatus(status) {
        const statusDot = document.querySelector('.status-dot');
        const statusText = statusDot.nextElementSibling;
        
        if (status === 'online') {
            statusDot.style.color = 'var(--success-color)';
            statusText.textContent = 'Server Online';
        } else {
            statusDot.style.color = 'var(--error-color)';
            statusText.textContent = 'Server Offline';
        }
    }
}

// Add slide animations to CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .notification-content {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
`;
document.head.appendChild(style);

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ThumbnailGenerator();
});

// Add some sample URLs for testing (can be removed in production)
window.addEventListener('load', () => {
    const pdfUrlInput = document.getElementById('pdfUrl');
    pdfUrlInput.placeholder = 'https://example.com/sample.pdf';
    
    // Add sample URLs in a datalist for easy testing
    const datalist = document.createElement('datalist');
    datalist.id = 'sample-urls';
    datalist.innerHTML = `
        <option value="https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf">
        <option value="https://www.africau.edu/images/default/sample.pdf">
        <option value="https://www.clickdimensions.com/links/TestPDFfile.pdf">
    `;
    document.body.appendChild(datalist);
    pdfUrlInput.setAttribute('list', 'sample-urls');
});
