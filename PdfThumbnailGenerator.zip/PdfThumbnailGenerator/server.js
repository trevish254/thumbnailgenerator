const express = require('express');
const axios = require('axios');
const pdf2pic = require('pdf2pic');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');
const { v4: uuidv4 } = require('uuid');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Initialize Supabase client
const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_ANON_KEY
);

// Middleware
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve static files
app.use(express.static('public'));
app.use('/thumbnails', express.static('thumbnails'));

// Ensure thumbnails directory exists
const thumbnailsDir = path.join(__dirname, 'thumbnails');
if (!fs.existsSync(thumbnailsDir)) {
    fs.mkdirSync(thumbnailsDir, { recursive: true });
    console.log('📁 Created thumbnails directory');
}

// Utility functions
const writeFileAsync = promisify(fs.writeFile);
const unlinkAsync = promisify(fs.unlink);

// Validate URL function
function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

// Generate thumbnail endpoint with Supabase integration
app.post('/generate-thumbnail', async (req, res) => {
    const startTime = Date.now();
    console.log('🚀 Starting thumbnail generation...');
    
    try {
        const { fileUrl, documentId } = req.body;
        
        // Validate input
        if (!fileUrl) {
            return res.status(400).json({
                success: false,
                error: 'Missing fileUrl parameter',
                message: 'Please provide a valid PDF URL'
            });
        }
        
        if (!documentId) {
            return res.status(400).json({
                success: false,
                error: 'Missing documentId parameter',
                message: 'Please provide a valid document ID'
            });
        }
        
        if (!isValidUrl(fileUrl)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid URL format',
                message: 'Please provide a valid PDF URL'
            });
        }
        
        // Generate filename based on documentId
        const tempPdfPath = path.join(__dirname, `temp_${documentId}.pdf`);
        const thumbnailFilename = `thumb_${documentId}.png`;
        const thumbnailPath = path.join(thumbnailsDir, thumbnailFilename);
        
        console.log(`📥 Downloading PDF from: ${fileUrl}`);
        
        // Download PDF
        const response = await axios({
            method: 'GET',
            url: fileUrl,
            responseType: 'arraybuffer',
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        // Check if response is actually a PDF
        const contentType = response.headers['content-type'];
        if (!contentType || !contentType.includes('application/pdf')) {
            console.warn(`⚠️  Warning: Content-Type is ${contentType}, expected application/pdf`);
        }
        
        // Save PDF temporarily
        await writeFileAsync(tempPdfPath, response.data);
        console.log(`💾 PDF saved temporarily as: ${tempPdfPath}`);
        
        // Convert PDF to PNG
        console.log('🔄 Converting PDF to PNG...');
        const convert = pdf2pic.fromPath(tempPdfPath, {
            density: 300,           // High quality
            saveFilename: `thumb_${documentId}`,
            savePath: thumbnailsDir,
            format: 'png',
            width: 400,
            height: 500,
            quality: 90
        });
        
        // Convert first page only
        const result = await convert(1, { responseType: 'image' });
        
        // Clean up temporary PDF
        try {
            await unlinkAsync(tempPdfPath);
            console.log('🗑️  Temporary PDF cleaned up');
        } catch (cleanupError) {
            console.warn('⚠️  Warning: Could not clean up temporary PDF:', cleanupError.message);
        }
        
        // pdf2pic creates files with .1.png extension for first page
        const actualThumbnailPath = path.join(thumbnailsDir, `thumb_${documentId}.1.png`);
        const finalThumbnailPath = path.join(thumbnailsDir, `thumb_${documentId}.png`);
        
        // Verify thumbnail was created
        if (!fs.existsSync(actualThumbnailPath)) {
            throw new Error('Thumbnail generation failed - file not created');
        }
        
        // Rename the file to remove the .1 part
        fs.renameSync(actualThumbnailPath, finalThumbnailPath);
        console.log('📁 Thumbnail file renamed to final name');
        
        // Upload thumbnail to Supabase Storage
        console.log('☁️  Uploading thumbnail to Supabase Storage...');
        const thumbnailBuffer = fs.readFileSync(finalThumbnailPath);
        
        const { data: uploadData, error: uploadError } = await supabase.storage
            .from('thumbnails')
            .upload(`thumb_${documentId}.png`, thumbnailBuffer, {
                contentType: 'image/png',
                upsert: true
            });
        
        if (uploadError) {
            throw new Error(`Failed to upload thumbnail: ${uploadError.message}`);
        }
        
        // Generate public URL for the thumbnail
        const { data: publicUrlData } = supabase.storage
            .from('thumbnails')
            .getPublicUrl(`thumb_${documentId}.png`);
        
        const thumbnailUrl = publicUrlData.publicUrl;
        console.log('🔗 Generated public URL:', thumbnailUrl);
        
        // Update document status in Supabase
        console.log('📝 Updating document status in Supabase...');
        const { error: updateError } = await supabase
            .from('documents')
            .update({
                thumbnail_url: thumbnailUrl,
                status: 'ready'
            })
            .eq('id', documentId);
        
        if (updateError) {
            console.warn('⚠️  Warning: Failed to update document status:', updateError.message);
        } else {
            console.log('✅ Document status updated successfully');
        }
        
        // Clean up local thumbnail file
        try {
            fs.unlinkSync(finalThumbnailPath);
            console.log('🗑️  Local thumbnail file cleaned up');
        } catch (cleanupError) {
            console.warn('⚠️  Warning: Could not clean up local thumbnail:', cleanupError.message);
        }
        
        const processingTime = Date.now() - startTime;
        console.log(`✅ Thumbnail generated and uploaded successfully in ${processingTime}ms`);
        
        // Return success response
        res.json({
            success: true,
            thumbnailUrl: thumbnailUrl,
            documentId: documentId,
            filename: thumbnailFilename,
            processingTime: `${processingTime}ms`,
            message: 'Thumbnail generated and uploaded successfully'
        });
        
    } catch (error) {
        console.error('❌ Error generating thumbnail:', error);
        
        // Update document status to failed in Supabase if documentId is available
        if (req.body.documentId) {
            try {
                await supabase
                    .from('documents')
                    .update({ status: 'failed' })
                    .eq('id', req.body.documentId);
                console.log('📝 Document status updated to failed');
            } catch (updateError) {
                console.warn('⚠️  Warning: Failed to update document status to failed:', updateError.message);
            }
        }
        
        // Clean up any temporary files
        const tempFiles = fs.readdirSync(__dirname).filter(file => file.startsWith('temp_'));
        tempFiles.forEach(file => {
            try {
                fs.unlinkSync(path.join(__dirname, file));
            } catch (cleanupError) {
                console.warn('⚠️  Could not clean up temp file:', file);
            }
        });
        
        // Clean up any local thumbnail files
        if (req.body.documentId) {
            try {
                const localThumbnailPath = path.join(thumbnailsDir, `thumb_${req.body.documentId}.png`);
                if (fs.existsSync(localThumbnailPath)) {
                    fs.unlinkSync(localThumbnailPath);
                }
            } catch (cleanupError) {
                console.warn('⚠️  Could not clean up local thumbnail file:', cleanupError.message);
            }
        }
        
        let errorMessage = 'An error occurred while generating the thumbnail';
        let statusCode = 500;
        
        if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
            errorMessage = 'Could not download the PDF - URL may be invalid or inaccessible';
            statusCode = 400;
        } else if (error.code === 'ETIMEDOUT') {
            errorMessage = 'Request timed out - the PDF may be too large or the server is slow';
            statusCode = 408;
        } else if (error.message.includes('PDF') || error.message.includes('thumbnail')) {
            errorMessage = 'Invalid PDF file or conversion failed';
            statusCode = 400;
        } else if (error.message.includes('Supabase') || error.message.includes('upload')) {
            errorMessage = 'Failed to upload thumbnail to storage';
            statusCode = 500;
        }
        
        res.status(statusCode).json({
            success: false,
            error: error.message,
            message: errorMessage,
            documentId: req.body.documentId || null,
            processingTime: `${Date.now() - startTime}ms`
        });
    }
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        thumbnailsGenerated: fs.readdirSync(thumbnailsDir).length,
        supabase: {
            url: process.env.SUPABASE_URL ? 'configured' : 'not configured',
            key: process.env.SUPABASE_ANON_KEY ? 'configured' : 'not configured'
        }
    });
});

// Test Supabase connection endpoint
app.get('/test-supabase', async (req, res) => {
    try {
        // Test Supabase connection by trying to read from documents table
        const { data, error } = await supabase
            .from('documents')
            .select('id')
            .limit(1);
        
        if (error) {
            throw error;
        }
        
        res.json({
            success: true,
            message: 'Supabase connection successful',
            documentsFound: data ? data.length : 0,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message,
            message: 'Failed to connect to Supabase',
            debug: {
                url: process.env.SUPABASE_URL ? 'present' : 'missing',
                key: process.env.SUPABASE_ANON_KEY ? 'present' : 'missing',
                keyLength: process.env.SUPABASE_ANON_KEY ? process.env.SUPABASE_ANON_KEY.length : 0
            }
        });
    }
});

// Simple thumbnail generation endpoint (local only, no Supabase)
app.post('/generate-thumbnail-local', async (req, res) => {
    const startTime = Date.now();
    console.log('🚀 Starting local thumbnail generation...');
    
    try {
        const { fileUrl } = req.body;
        
        if (!fileUrl || !isValidUrl(fileUrl)) {
            return res.status(400).json({
                success: false,
                message: 'Please provide a valid PDF URL'
            });
        }
        
        const uniqueId = uuidv4();
        const tempPdfPath = path.join(__dirname, `temp_${uniqueId}.pdf`);
        const thumbnailFilename = `thumbnail_${uniqueId}.png`;
        
        // Download PDF
        console.log(`📥 Downloading PDF from: ${fileUrl}`);
        const response = await axios({
            method: 'GET',
            url: fileUrl,
            responseType: 'arraybuffer',
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        await writeFileAsync(tempPdfPath, response.data);
        
        // Convert PDF to PNG
        console.log('🔄 Converting PDF to PNG...');
        const convert = pdf2pic.fromPath(tempPdfPath, {
            density: 300,
            saveFilename: `thumbnail_${uniqueId}`,
            savePath: thumbnailsDir,
            format: 'png',
            width: 400,
            height: 500,
            quality: 90
        });
        
        await convert(1, { responseType: 'image' });
        
        // Clean up PDF
        await unlinkAsync(tempPdfPath);
        
        // Rename thumbnail file
        const actualThumbnailPath = path.join(thumbnailsDir, `thumbnail_${uniqueId}.1.png`);
        const finalThumbnailPath = path.join(thumbnailsDir, `thumbnail_${uniqueId}.png`);
        fs.renameSync(actualThumbnailPath, finalThumbnailPath);
        
        const processingTime = Date.now() - startTime;
        console.log(`✅ Local thumbnail generated successfully in ${processingTime}ms`);
        
        res.json({
            success: true,
            thumbnailUrl: `/thumbnails/${thumbnailFilename}`,
            filename: thumbnailFilename,
            processingTime: `${processingTime}ms`,
            message: 'Thumbnail generated successfully (local only)'
        });
        
    } catch (error) {
        console.error('❌ Error generating local thumbnail:', error);
        res.status(500).json({
            success: false,
            error: error.message,
            processingTime: `${Date.now() - startTime}ms`
        });
    }
});

// List thumbnails endpoint
app.get('/thumbnails-list', (req, res) => {
    try {
        const thumbnails = fs.readdirSync(thumbnailsDir)
            .filter(file => file.endsWith('.png'))
            .map(file => {
                const filePath = path.join(thumbnailsDir, file);
                const stats = fs.statSync(filePath);
                return {
                    filename: file,
                    url: `/thumbnails/${file}`,
                    size: stats.size,
                    created: stats.birthtime
                };
            })
            .sort((a, b) => new Date(b.created) - new Date(a.created));
        
        res.json({
            success: true,
            count: thumbnails.length,
            thumbnails: thumbnails
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`
🎨 ═══════════════════════════════════════════════════════════════
   PDF THUMBNAIL GENERATOR SERVER
   Award-winning design meets powerful functionality
═══════════════════════════════════════════════════════════════

🚀 Server running on: http://localhost:${PORT}
📁 Thumbnails directory: ${thumbnailsDir}
🌐 CORS enabled for external access
⚡ Ready to generate beautiful thumbnails!

Available endpoints:
• POST /generate-thumbnail - Generate thumbnail from PDF URL
• GET  /thumbnails-list   - List all generated thumbnails
• GET  /health           - Server health check
• GET  /                 - Beautiful web interface

═══════════════════════════════════════════════════════════════
    `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('🔄 SIGTERM received, shutting down gracefully...');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('🔄 SIGINT received, shutting down gracefully...');
    process.exit(0);
});
