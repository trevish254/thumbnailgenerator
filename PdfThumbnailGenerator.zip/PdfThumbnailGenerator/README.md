# PDF Thumbnail Generator with Supabase Integration

A Node.js Express server that generates PNG thumbnails from PDF URLs and uploads them to Supabase Storage with automatic document status management.

## Features

- **PDF Processing**: Downloads PDFs and converts first page to 400x500 PNG thumbnails
- **Supabase Integration**: Uploads thumbnails to Supabase Storage and updates document status
- **Beautiful Web Interface**: Award-winning responsive design with real-time feedback
- **Automatic Cleanup**: Removes temporary files after processing
- **Error Handling**: Comprehensive error handling with status updates
- **CORS Support**: Enabled for external API access

## Installation

### Dependencies

Install the required packages:

```bash
npm install express axios cors fs path pdf2pic @supabase/supabase-js dotenv uuid
```

### System Requirements

The application requires GraphicsMagick for PDF processing:

```bash
# On Ubuntu/Debian
sudo apt-get install graphicsmagick

# On macOS
brew install graphicsmagick

# On Replit (NixOS)
# Already installed via packager_tool
```

### Environment Setup

1. Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

2. Update `.env` with your Supabase credentials:
```env
SUPABASE_URL=https://lbtiglcyhudkhuzbgfvm.supabase.co
SUPABASE_ANON_KEY=your_complete_supabase_anon_key_here
PORT=5000
NODE_ENV=development
```

## Supabase Setup

### Database Schema

Your Supabase project should have a `documents` table with the following structure:

```sql
CREATE TABLE documents (
  id TEXT PRIMARY KEY,
  thumbnail_url TEXT,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### Storage Setup

1. Create a storage bucket named `thumbnails`
2. Set the bucket to public read access
3. Configure the bucket for image uploads

### Required Permissions

The anonymous key should have:
- SELECT, UPDATE permissions on `documents` table
- INSERT, SELECT permissions on `thumbnails` storage bucket

## API Endpoints

### Generate Thumbnail
```
POST /generate-thumbnail
Content-Type: application/json

{
  "fileUrl": "https://example.com/document.pdf",
  "documentId": "unique-document-id"
}
```

**Response:**
```json
{
  "success": true,
  "thumbnailUrl": "https://supabase-url/storage/v1/object/public/thumbnails/thumb_doc123.png",
  "documentId": "doc123",
  "filename": "thumb_doc123.png",
  "processingTime": "1250ms",
  "message": "Thumbnail generated and uploaded successfully"
}
```

### Health Check
```
GET /health
```

### Test Supabase Connection
```
GET /test-supabase
```

### List Thumbnails
```
GET /thumbnails-list
```

## Usage

### Start the Server

```bash
node server.js
```

The server will start on port 5000 and display:
```
🎨 ═══════════════════════════════════════════════════════════════
   PDF THUMBNAIL GENERATOR SERVER
   Award-winning design meets powerful functionality
═══════════════════════════════════════════════════════════════

🚀 Server running on: http://localhost:5000
📁 Thumbnails directory: /home/runner/workspace/thumbnails
🌐 CORS enabled for external access
⚡ Ready to generate beautiful thumbnails!
```

### Web Interface

Visit `http://localhost:5000` to access the beautiful web interface where you can:
- Enter PDF URLs and document IDs
- Generate thumbnails with real-time progress
- View recent thumbnails
- Copy URLs and download thumbnails

### Programmatic Usage

```javascript
// Generate thumbnail
const response = await fetch('http://localhost:5000/generate-thumbnail', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    fileUrl: 'https://example.com/document.pdf',
    documentId: 'doc123'
  })
});

const result = await response.json();
console.log(result.thumbnailUrl); // Supabase public URL
```

## Process Flow

1. **Request**: Client sends PDF URL and document ID
2. **Download**: Server downloads PDF using axios
3. **Convert**: pdf2pic converts first page to PNG (400x500)
4. **Upload**: Thumbnail uploaded to Supabase Storage (`thumbnails` bucket)
5. **Update**: Document status set to `"ready"` with thumbnail URL
6. **Cleanup**: Temporary files removed
7. **Response**: Public URL returned to client

## Error Handling

- **Invalid URLs**: Returns 400 with validation error
- **Download failures**: Returns 400 with network error
- **Conversion failures**: Returns 400 with PDF processing error
- **Upload failures**: Returns 500 with storage error
- **Database errors**: Updates document status to `"failed"`

## File Structure

```
.
├── server.js           # Main Express server
├── public/
│   ├── index.html     # Web interface
│   ├── style.css      # Beautiful styling
│   └── script.js      # Frontend JavaScript
├── thumbnails/        # Local thumbnail storage (temporary)
├── .env.example       # Environment template
├── .env              # Environment variables
└── README.md         # This file
```

## Troubleshooting

### Supabase Connection Issues
1. Verify SUPABASE_URL and SUPABASE_ANON_KEY are correct
2. Check if the `documents` table exists
3. Ensure the `thumbnails` storage bucket is created and public
4. Test connection with `/test-supabase` endpoint

### PDF Processing Issues
1. Ensure GraphicsMagick is installed
2. Check if PDF URL is accessible
3. Verify PDF file is valid and not corrupted

### Upload Issues
1. Check Supabase storage permissions
2. Verify bucket name is `thumbnails`
3. Ensure anonymous key has storage access

## Dependencies

- **express**: Web framework
- **axios**: HTTP client for PDF downloads
- **pdf2pic**: PDF to image conversion
- **@supabase/supabase-js**: Supabase client
- **cors**: Cross-origin resource sharing
- **dotenv**: Environment variables
- **uuid**: Unique ID generation
- **fs, path**: File system operations

## License

MIT License - Feel free to use in your projects!