# PDF Thumbnail Generator

## Overview

This is a Node.js-based web application that generates thumbnails from PDF documents. The application accepts PDF URLs, downloads the PDFs, converts them to image thumbnails, and provides a user-friendly interface for managing and viewing the generated thumbnails.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a simple client-server architecture:

- **Frontend**: Static HTML/CSS/JavaScript served by Express.js
- **Backend**: Node.js with Express.js REST API
- **File Storage**: Local filesystem for temporary PDF storage and thumbnail images
- **PDF Processing**: pdf2pic library for PDF to image conversion

## Key Components

### Backend Components

1. **Express Server** (`server.js`)
   - Handles HTTP requests and responses
   - Serves static files and API endpoints
   - Implements CORS for cross-origin requests
   - Manages file uploads and processing

2. **PDF Processing Pipeline**
   - Downloads PDFs from provided URLs using axios
   - Converts PDF pages to images using pdf2pic
   - Generates unique filenames using UUID
   - Stores thumbnails in local directory

3. **File Management**
   - Creates and manages thumbnails directory
   - Handles temporary file cleanup
   - Serves static thumbnail files

### Frontend Components

1. **User Interface** (`public/index.html`)
   - Modern, responsive design
   - PDF URL input form
   - Thumbnail preview and management
   - Recent thumbnails gallery

2. **JavaScript Client** (`public/script.js`)
   - Form handling and validation
   - API communication
   - Real-time status updates
   - File download functionality

3. **Styling** (`public/style.css`)
   - Modern CSS with custom properties
   - Responsive design
   - Professional visual aesthetics

## Data Flow

1. **Thumbnail Generation Process**:
   - User submits PDF URL through web interface
   - Backend validates URL and downloads PDF
   - PDF is converted to image using pdf2pic
   - Thumbnail is saved to local filesystem
   - Response includes thumbnail URL and metadata

2. **File Serving**:
   - Static files served from `/public` directory
   - Thumbnails served from `/thumbnails` directory
   - All files accessible via HTTP endpoints

## External Dependencies

### Core Dependencies
- **express**: Web framework for Node.js
- **axios**: HTTP client for downloading PDFs
- **pdf2pic**: PDF to image conversion library
- **cors**: Cross-origin resource sharing middleware
- **uuid**: Unique identifier generation

### Frontend Dependencies
- **Font Awesome**: Icon library
- **Google Fonts**: Typography (Inter font family)

## Deployment Strategy

### Local Development
- Start server with `npm start`
- Server runs on port 3000
- Static files served from Express

### Production Considerations
- No database required (file-based storage)
- Thumbnails directory auto-created on startup
- CORS configured for open access
- File size limits set to 50MB for large PDFs

### Environment Requirements
- Node.js runtime
- Sufficient disk space for temporary files
- Network access for downloading PDFs
- System dependencies for pdf2pic (GraphicsMagick installed)

### Scaling Considerations
- Current implementation uses local filesystem
- For production scale, consider cloud storage
- Implement cleanup mechanisms for old thumbnails
- Add rate limiting for API endpoints
- Consider adding database for metadata storage

## Current Status (July 13, 2025)

### Recent Changes
- **Supabase Integration**: Added complete Supabase integration for thumbnail storage and document management
- **API Enhancement**: Updated `/generate-thumbnail` endpoint to accept `documentId` parameter
- **Database Integration**: Automatic status updates in `documents` table (ready/failed)
- **Storage Upload**: Thumbnails uploaded to Supabase Storage (`thumbnails` bucket)
- **Error Handling**: Enhanced error handling with Supabase status updates on failures
- **Environment Setup**: Added `.env` support with Supabase credentials
- **Documentation**: Created comprehensive README.md with setup instructions
- **Testing Endpoints**: Added `/test-supabase` and `/generate-thumbnail-local` for debugging

### Application Status
- **Server**: Running successfully on port 5000
- **Core Functionality**: PDF thumbnail generation fully working (verified)
- **Local Processing**: Successfully converts PDFs to 400x500 PNG thumbnails
- **Supabase Setup**: Environment configured, connection pending verification
- **API Endpoints**: Multiple endpoints for different use cases
- **Frontend**: Updated web interface with document ID support
- **CORS**: Enabled for external tool access

### API Endpoints
- `POST /generate-thumbnail` - Full Supabase integration (requires documentId)
- `POST /generate-thumbnail-local` - Local generation only (testing)
- `GET /test-supabase` - Test Supabase connection
- `GET /thumbnails-list` - List local thumbnails
- `GET /health` - Server health with Supabase status
- `GET /` - Beautiful web interface

### Verified Features
- PDF URL validation and downloading
- High-quality thumbnail generation (300 DPI) ✅
- Local file processing and cleanup ✅
- Supabase client initialization ✅
- Document ID validation ✅
- Enhanced error handling ✅
- Beautiful responsive web interface ✅
- Environment variable configuration ✅

### Pending Verification
- Supabase database connection (requires proper table setup)
- Supabase Storage upload functionality
- Document status updates in database
- End-to-end workflow with real document IDs